
var modal = new Vue({
  template: '<div></div>',
  data() {
    return {

    }
  },
  mounted() {
    document.body.appendChild(this.$el)
  }
})